To run this script place it in a matlab environment and then hit run. 

All sounds are commented out. If you want to hear any of the original 
signals they are near the top of the code, if you want hear the cleaned
up signal it is at the end of the script. You must uncomment those lines
if you want to hear the sound. 

If you want to adjust the mu or the FFT size those variables are near the 
top of the script as well. 